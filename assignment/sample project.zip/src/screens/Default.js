import React from 'react'

export default function Default() {
  return (
    <div className="default-screen">
      Select task from left panel to continue
    </div>
  )
}
