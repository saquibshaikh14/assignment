/*
 * Created on Fri Jul 16 2021
 * Author: Saquib Shaikh
 * Github: https://github.com/saquibshaikh14
 * Email: mdsqb0786@gmail.com
 *
 */

import React from 'react';

const PPT = () =>{

  return (
    <div>
      <p>
        Incomplete: <br/>
        Cannot find any module for offline ppt view.
      </p>
    </div>
  )
}

export default PPT;